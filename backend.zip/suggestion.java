package com.example.srm1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class suggestion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggestion);
    }
}
