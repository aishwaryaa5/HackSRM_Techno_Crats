package com.example.srm1;

public class pull {
    private static String by;

    public pull() {
    }

    public pull(String by) {
        this.by = by;

    }

    public static String getBy()
    {
        return by;
    }


    public void setBy(String by) {

        this.by = by;
    }

}

