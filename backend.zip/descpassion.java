package com.example.srm1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class descpassion extends AppCompatActivity implements View.OnClickListener {
    DatabaseReference reff123,reff1234;
    public static final String SharedPreffs= "SharedPreffs";
    TextView tn,tl,td;
    public String b;
    public int bb;
    ImageButton imageButton;
   String a;
    ArrayList<comments> namee=new ArrayList<>();
    public String child,pullchild;
    ListView listView1;
    EditText editText;
    DatabaseReference reff1,refff;
    int n;
    String namess, comment;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_descpassion);
        tn=findViewById(R.id.dispnamechange);
        tl=findViewById(R.id.displocationchange);
        td=findViewById(R.id.dispdescription);
        imageButton=findViewById(R.id.thumb);
        imageButton.setOnClickListener(this);
        editText=findViewById(R.id.edit_comment);

        button=findViewById(R.id.button_comment);
        button.setOnClickListener(this);
        listView1=findViewById(R.id.commnetslist);
        final Commentlistadapter adapter = new Commentlistadapter(this,R.layout.custom_list_comments,namee);
        SharedPreferences sharedPreferences=getSharedPreferences(SharedPreffs,MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        a=sharedPreferences.getString("Passion_Selected","education");
        Log.d(" Passion Selected id",""+a);
        reff123= FirebaseDatabase.getInstance().getReference("main");
        reff123.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                child=dataSnapshot.child("request").getValue().toString();
                Log.d("got child",""+child);
                String name=dataSnapshot.child("passion").child(a).child(child).child("name").getValue().toString();
                String desc=dataSnapshot.child("passion").child(a).child(child).child("description").getValue().toString();
                String locate=dataSnapshot.child("passion").child(a).child(child).child("location").getValue().toString();
                tn.setText(name);
                tl.setText(locate);
                td.setText(desc);
                namee.clear();
                listView1.setAdapter(adapter);
                for(DataSnapshot d:dataSnapshot.child("comments").child(child).getChildren()){
                    comments p=d.getValue(comments.class);//child("comments").child(child)
                    namee.add(p);
                }
                listView1.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

     /*  reff1= FirebaseDatabase.getInstance().getReference("main");
        reff1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                child=dataSnapshot.child("request").getValue().toString();
                namee.clear();
                listView1.setAdapter(adapter);
                for(DataSnapshot d:dataSnapshot.getChildren()){
                    comments p=d.child("comments").child(child).getValue(comments.class);
                    namee.add(p);
                }
                listView1.setAdapter(adapter);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });*/




    }

    @Override
    public void onClick(View v) {
        if(v==imageButton){
            Log.d("Inside onclick","onclick");
            reff1234=FirebaseDatabase.getInstance().getReference("main").child("passion");
            reff1234.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Log.d("Inside ondata","ondata");
                    try{
                        Log.d("Inside try","try");
                    b=dataSnapshot.child(a).child(child).child("votes").getValue().toString();
                        bb=Integer.parseInt(b);
                    Log.d("votes is",""+b);}
                    catch (NumberFormatException e)
                        {
                            b="0";
                        }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

            Log.d("votes",""+bb);
            bb++;
            String bbb=String.valueOf(bb);
            reff1234.child(a).child(child).child("votes").setValue(bbb);


        }
        if(v == button){
            comment=editText.getText().toString();
            SharedPreferences sharedPreferences=getSharedPreferences(SharedPreffs,MODE_PRIVATE);
            namess=sharedPreferences.getString("Name","a");


            refff=FirebaseDatabase.getInstance().getReference("main");
            refff.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    child=dataSnapshot.child("request").getValue().toString();
                    try{
                        n = (int) dataSnapshot.child("comments").child(child).getChildrenCount();

                    }
                    catch (NullPointerException e){
                        n=0;
                    }
                    Log.d("Count : ",""+n);

                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }

            });
            refff.child("comments").child(child).child("comment"+(n+1)).child("by").setValue(namess);
            refff.child("comments").child(child).child("comment"+(n+1)).child("commentdesc").setValue(comment);


        }

    }
}
